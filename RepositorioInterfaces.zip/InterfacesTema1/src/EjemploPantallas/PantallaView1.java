package EjemploPantallas;

import javax.swing.JLabel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;

public class PantallaView1 extends View {
	public PantallaView1(App appController) {
		super(appController);
		setLayout(null);

		JLabel lblPantalla = new JLabel("Pantalla 1");
		lblPantalla.setBounds(189, 31, 96, 41);
		add(lblPantalla);

		JButton botonSiguiente = new JButton("Ir a pantalla due");
		botonSiguiente.setBounds(131, 128, 167, 73);
		botonSiguiente.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				appController.irPantalla2();
			}
		});
		add(botonSiguiente);

		txtUsuario = new JTextField();
		txtUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		txtUsuario.setBounds(171, 71, 86, 20);
		add(txtUsuario);
		txtUsuario.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setHorizontalAlignment(SwingConstants.CENTER);
		passwordField.setBounds(171, 102, 86, 20);
		add(passwordField);

		JButton botonLogin = new JButton("Login");
		botonLogin.setBounds(168, 223, 89, 23);
		botonLogin.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String user = txtUsuario.getText();
				String password = new String(passwordField.getPassword());
				appController.login(user, password);

			}
		});
		add(botonLogin);

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -673874809679017780L;
	private JTextField txtUsuario;
	private JPasswordField passwordField;
}
