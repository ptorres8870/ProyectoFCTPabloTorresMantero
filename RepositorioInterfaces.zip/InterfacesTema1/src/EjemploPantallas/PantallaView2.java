package EjemploPantallas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;

public class PantallaView2 extends View {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7822277400480302507L;

	public PantallaView2(App appController) {
		super(appController);
		setLayout(null);

		JLabel lblNewLabel = new JLabel("Pantalla 2");
		lblNewLabel.setBounds(181, 35, 96, 41);
		add(lblNewLabel);

		JButton botonSiguiente = new JButton("Ir a pantalla tre");
		botonSiguiente.setBounds(127, 98, 167, 73);
		botonSiguiente.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				appController.irPantalla3();
				
			}
		});
		add(botonSiguiente);
	}
}
