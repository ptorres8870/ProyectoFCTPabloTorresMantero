package ejercicio14;

import javax.swing.JPanel;

public abstract class View extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2665559096866707542L;

	protected App appController;

	public View(App appController) {
		this.appController = appController;
	}

}
