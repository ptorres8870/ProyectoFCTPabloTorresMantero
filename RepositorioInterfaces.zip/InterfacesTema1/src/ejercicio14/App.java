package ejercicio14;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class App {

	private JFrame frame;

	private PantallaView1 pantalla1;
	private PantallaView2 pantalla2;
	private PantallaView3 pantalla3;
	private BienvenidaView pantallaBienvenida;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					App window = new App();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public App() {
		initialize();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		pantallaBienvenida = new BienvenidaView(this);
		pantalla1 = new PantallaView1(this);
		pantalla2 = new PantallaView2(this);
		pantalla3 = new PantallaView3(this);
		
		
		irPantallaBienvenida();

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 434, 22);
		frame.setJMenuBar(menuBar);

		JMenu irMenu = new JMenu("file");
		menuBar.add(irMenu);

		JMenuItem direccionPantalla1 = new JMenuItem("Ir a pantalla 1");
		irMenu.add(direccionPantalla1);
		ActionListener dirPanta1 = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				irPantalla1(null);
			}
		};
		direccionPantalla1.addActionListener(dirPanta1);

		JMenuItem direccionPantalla2 = new JMenuItem("Ir a pantalla 2");
		irMenu.add(direccionPantalla2);
		ActionListener dirPanta2 = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				irPantalla2(null);
			}
		};
		direccionPantalla2.addActionListener(dirPanta2);

		JMenuItem direccionPantalla3 = new JMenuItem("Ir a pantalla 3");
		irMenu.add(direccionPantalla3);
		ActionListener dirPanta3 = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				irPantalla3(null);
			}
		};
		direccionPantalla3.addActionListener(dirPanta3);

		JMenu salirMenu = new JMenu("Salir");
		menuBar.add(salirMenu);

		JMenuItem salirMenuItem = new JMenuItem("Salir");
		salirMenu.add(salirMenuItem);

		ActionListener salirListener = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(salirMenuItem, "Estas seguro?", "¿Salir?",
						JOptionPane.YES_NO_OPTION) != 1) {
					System.exit(0);
				} else {

				}

			}
		};

		salirMenuItem.addActionListener(salirListener);
		frame.getJMenuBar().setVisible(false);
	}

	public void irPantallaBienvenida() {
		frame.setContentPane(pantallaBienvenida);
		frame.revalidate();
	}
	public void irPantalla1(String msj) {
		frame.setContentPane(pantalla1);
		frame.getJMenuBar().setVisible(true);
		pantalla1.setMensaje(msj);
		frame.revalidate();
	}

	public void irPantalla2(String msj) {
		frame.setContentPane(pantalla2);
		frame.getJMenuBar().setVisible(true);
		pantalla2.setMensaje(msj);
		frame.revalidate();

	}

	public void irPantalla3(String msj) {
		frame.setContentPane(pantalla3);
		frame.getJMenuBar().setVisible(true);
		pantalla3.setMensaje(msj);
		frame.revalidate();

	}

}
