package ejercicio15;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class PantallaView2 extends View {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7822277400480302507L;

	private JTextField txtUsuario;

	public PantallaView2(App appController) {
		super(appController);
		setLayout(null);

		JLabel lblPantalla = new JLabel("Pantalla 2");
		lblPantalla.setHorizontalAlignment(SwingConstants.CENTER);
		lblPantalla.setBounds(171, 26, 86, 34);
		add(lblPantalla);

		txtUsuario = new JTextField();
		txtUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		txtUsuario.setBounds(171, 71, 86, 20);
		add(txtUsuario);
		txtUsuario.setColumns(10);

		JButton botonSiguiente1 = new JButton("Ir a pantalla uno");
		botonSiguiente1.setBounds(131, 102, 168, 41);
		botonSiguiente1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				appController.irPantalla1(txtUsuario.getText());
			}
		});
		add(botonSiguiente1);

		JButton botonSiguiente2 = new JButton("Ir a pantalla due");
		botonSiguiente2.setEnabled(false);
		botonSiguiente2.setBounds(131, 154, 168, 41);
		botonSiguiente2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				appController.irPantalla2(txtUsuario.getText());
			}
		});
		add(botonSiguiente2);

		JButton botonSiguiente3 = new JButton("Ir a pantalla tre");
		botonSiguiente3.setBounds(131, 206, 168, 41);
		botonSiguiente3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				appController.irPantalla3(txtUsuario.getText());
			}
		});
		add(botonSiguiente3);

	}
	public void setMensaje(String msj) {
		txtUsuario.setText(msj);
	}

}
