package ejercicio15;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class BienvenidaView extends View {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6674488697093183139L;

	public BienvenidaView(App appController) {
		super(appController);
		setLayout(null);
		
		JLabel labelBienvenida = new JLabel("Welcome to my app");
		labelBienvenida.setHorizontalAlignment(SwingConstants.CENTER);
		labelBienvenida.setBounds(106, 83, 201, 14);
		add(labelBienvenida);
		
		JButton botonBienvenida = new JButton("Entrar!!");
		botonBienvenida.setBounds(165, 135, 89, 23);
		add(botonBienvenida);
		
		ActionListener botonEntrar = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				appController.irPantalla1(null);
			}
		};
		
		botonBienvenida.addActionListener(botonEntrar);
	}
}
