package interfaz;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Ejercicio5 {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ejercicio5 window = new Ejercicio5();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Ejercicio5() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JButton boton = new JButton("Sumar");

		boton.setBounds(0, 0, 434, 131);
		frame.getContentPane().add(boton);

		JLabel label = new JLabel("");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(0, 128, 434, 133);
		frame.getContentPane().add(label);

		ActionListener accionBoton = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (label.getText().isEmpty()) {
					label.setText("1");
				}else {
					label.setText(Integer.parseInt(label.getText())+ 1 +"");
				}
			}
		};
		boton.addActionListener(accionBoton);
	}
}
