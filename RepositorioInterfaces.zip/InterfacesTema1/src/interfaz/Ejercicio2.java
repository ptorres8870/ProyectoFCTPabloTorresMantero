package interfaz;

import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Ejercicio2 {
	public static JFrame ventana;

	public static void main(String[] args) {
		crearVentana();
	}

	public static void crearVentana() {
		ventana = new JFrame();
		ventana.setTitle("Añadir usuario");
		ventana.setSize(400, 200);
		ventana.setLocationRelativeTo(null);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Container contenedor = ventana.getContentPane();

		GridLayout layout = new GridLayout(4, 2);
		ventana.setLayout(layout);

		JLabel nombre = new JLabel("Nombre: ");

		contenedor.add(nombre);
		
		JTextField nombree = new JTextField();

		contenedor.add(nombree);

		JLabel dni = new JLabel("DNI: ");

		contenedor.add(dni);
		
		JTextField dnii = new JTextField();

		contenedor.add(dnii);

		JLabel fechaNac = new JLabel("fechaNac: ");

		contenedor.add(fechaNac);
		
		JPanel panelFecha = new JPanel();
		contenedor.add(panelFecha);
		
		JTextField uno = new JTextField(2);
		panelFecha.add(uno);
		
		JLabel barra = new JLabel("/");
		panelFecha.add(barra);
		
		JTextField dos = new JTextField(2);
		panelFecha.add(dos);
		
		JLabel barra2 = new JLabel("/");
		panelFecha.add(barra2);
		
		JTextField tres = new JTextField(2);
		panelFecha.add(tres);
		
		JButton boton1 = new JButton("Aceptar");
		contenedor.add(boton1);
		JButton boton2 = new JButton("Cancelar");
		contenedor.add(boton2);

		
		
		ventana.setVisible(true);
	}
}
