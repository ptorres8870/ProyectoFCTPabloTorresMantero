package interfaz;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Ejercicio6 {

	public JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ejercicio6 window = new Ejercicio6();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * 
	 * @wbp.parser.entryPoint
	 */
	public Ejercicio6() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JButton boton = new JButton("Sumar");
		boton.setBounds(0, 0, 434, 131);
		frame.getContentPane().add(boton);

		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setBounds(0, 129, 434, 132);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		ActionListener accionBoton = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (textField.getText().isEmpty()) {
						textField.setText("1");
					} else {
						textField.setText(Integer.parseInt(textField.getText()) + 1 + "");
					}

				} catch (Exception e2) {
					JOptionPane.showMessageDialog(frame, "El botón no admite letras.", "ERROR",
							JOptionPane.ERROR_MESSAGE);
					textField.setText("");
				}
			}
		};
		boton.addActionListener(accionBoton);
	}
}
