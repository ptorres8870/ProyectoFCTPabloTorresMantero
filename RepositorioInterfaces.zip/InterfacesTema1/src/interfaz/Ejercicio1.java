package interfaz;

import java.awt.Container;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Ejercicio1 {
	public static JFrame ventana;

	public static void main(String[] args) {
		crearVentana();
	}

	public static void crearVentana() {
		ventana = new JFrame();
		ventana.setTitle("Ventanuco");
		ventana.setSize(500, 500);
		ventana.setLocationRelativeTo(null);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Container contenedor = ventana.getContentPane();

		for (int i = 1; i <= 5; i++) {

			JLabel boton = new JLabel();
			boton.setText("Texto " + i);
			contenedor.add(boton);

		}

		GridLayout layout = new GridLayout(3, 2);
		ventana.setLayout(layout);

		JPanel panel = new JPanel();
		GridLayout layout2 = new GridLayout(2, 2);
		panel.setLayout(layout2);
		contenedor.add(panel);

		for (int i = 61; i <= 64; i++) {

			JLabel label2 = new JLabel();
			panel.add(label2);
			label2.setText("Texto " + i);
		}

		ventana.setVisible(true);
	}
}
