package interfaz;

import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Ventana {

	public static JFrame ventana;

	public static void main(String[] args) {
		crearVentana();
	}

	public static void crearVentana() {
		ventana = new JFrame();
		ventana.setTitle("Ventanuco");
		ventana.setSize(500, 500);
		ventana.setLocationRelativeTo(null);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Container contenedor = ventana.getContentPane();
		JButton boton = new JButton();
		boton.setText("Presioname");
		contenedor.add(boton);

		GridLayout layout = new GridLayout(4, 2);
		ventana.setLayout(layout);

		JButton boton2 = new JButton();
		boton2.setText("Cancelame");
		contenedor.add(boton2);

		JPanel panel = new JPanel();
		GridLayout layout2 = new GridLayout(1, 2);
		panel.setLayout(layout2);
		contenedor.add(panel);

		for (Integer contador = 1; contador <= 5; contador++) {
			JButton boton3 = new JButton();
			boton3.setText("Boton " + contador);
			contenedor.add(boton3);
		}

		for (int i = 0; i < 2; i++) {
			JButton botonn = new JButton();
			panel.add(botonn);
			botonn.setText("Prueba");
		}
		ventana.setVisible(true);
	}
}
