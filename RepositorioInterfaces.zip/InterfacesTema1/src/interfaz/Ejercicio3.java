package interfaz;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Ejercicio3 {
	public static JFrame ventana;

	public static void main(String[] args) {
		crearVentana();
		cargarComponentes();
	}

	public static void crearVentana() {
		ventana = new JFrame();
		ventana.setTitle("Ventanuco");
		ventana.setSize(500, 500);
		ventana.setLocationRelativeTo(null);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void cargarComponentes() {
		GridLayout layout = new GridLayout(4, 1);
		ventana.setLayout(layout);
		JLabel label = new JLabel("¿Donde has hecho click?");

		ActionListener listenerBotones = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				String actionCommandOrigen = e.getActionCommand();
				label.setText("Has hecho click en el botón " + actionCommandOrigen);

			}
		};

		for (int i = 1; i <= 3; i++) {
			JButton boton = new JButton();
			boton.addActionListener(listenerBotones);
			boton.setText(String.valueOf(i));
			boton.setActionCommand("Botón " + i);
			ventana.add(boton);
		}

		ventana.add(label);
		ventana.setVisible(true);
	}
}