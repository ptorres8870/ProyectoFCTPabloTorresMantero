package interfaz.Ejercicio6Diferente;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Ejercicio6ActionListener implements ActionListener {

	public JFrame frame;
	public JTextField textField;

	public Ejercicio6ActionListener(JFrame Jframe, JTextField JtextField) {
		frame = Jframe;
		textField = JtextField;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			if (textField.getText().isEmpty()) {
				textField.setText("1");
			} else {
				textField.setText(Integer.parseInt(textField.getText()) + 1 + "");
			}

		} catch (Exception e2) {
			JOptionPane.showMessageDialog(frame, "El botón no admite letras.", "ERROR", JOptionPane.ERROR_MESSAGE);
			textField.setText("");
		}

	}

}
