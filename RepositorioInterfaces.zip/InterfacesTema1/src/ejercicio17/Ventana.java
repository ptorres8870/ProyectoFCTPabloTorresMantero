package ejercicio17;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import ejercicio01.modelo.Pelicula;
import ejercicio01.services.PeliculasException;
import ejercicio01.services.PeliculasService;

public class Ventana {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana window = new Ventana();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Ventana() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JButton botonConsultar = new JButton("Consultar");
		botonConsultar.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(botonConsultar);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 414, 200);
		frame.getContentPane().add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);
		TableModel modelo = new TableModel();
		table.setModel(modelo);

		ActionListener pulsarBoton = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					PeliculasService peliService = new PeliculasService();
					List<Pelicula> peli = peliService.consultarPeliculas();
					modelo.setListaPelis(peli);
					modelo.fireTableDataChanged();

				} catch (PeliculasException e2) {
					JOptionPane.showMessageDialog(frame, e2.getMessage(), "ERROR BBDD", JOptionPane.ERROR_MESSAGE);
					e2.printStackTrace();
				}
			}
		};

		botonConsultar.addActionListener(pulsarBoton);
	}
}
