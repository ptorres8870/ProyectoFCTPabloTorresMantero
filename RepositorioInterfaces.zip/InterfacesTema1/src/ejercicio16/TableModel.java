package ejercicio16;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

public class TableModel extends AbstractTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<Nombre> listaNombres;

	public TableModel() {
		listaNombres = new ArrayList<Nombre>();
	}

	public List<Nombre> getListaNombres() {
		return listaNombres;
	}

	public void setListaNombres(List<Nombre> listaNombres) {
		this.listaNombres = listaNombres;
	}

	@Override
	public int getRowCount() {
		return listaNombres.size();
	}

	@Override
	public int getColumnCount() {
		return 2;
	}

	@Override
	public String getColumnName(int column) {
		if (column == 0) {
			return "Nombre";

		} else {
			return "Apellidos";

		}
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Nombre nombre = listaNombres.get(rowIndex);
		if (columnIndex == 0) {
			return nombre.getNombre();
		} else {
			return nombre.getApellidos();
		}

	}

}
