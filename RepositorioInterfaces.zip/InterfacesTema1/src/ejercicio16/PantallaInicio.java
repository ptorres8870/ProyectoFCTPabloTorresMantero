package ejercicio16;

import java.awt.EventQueue;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class PantallaInicio {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField2;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PantallaInicio window = new PantallaInicio();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PantallaInicio() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		textField = new JTextField();
		textField.setBounds(86, 32, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		textField2 = new JTextField();
		textField2.setBounds(271, 32, 86, 20);
		frame.getContentPane().add(textField2);
		textField2.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(86, 98, 277, 139);
		frame.getContentPane().add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);

		TableModel modelo = new TableModel();
		table.setModel(modelo);
		;

		KeyListener presionarEnter1 = new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {

			}

			@Override
			public void keyReleased(KeyEvent e) {

			}

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					if (!textField.getText().isBlank()) {
						textField2.requestFocus();
					}
				}

			}
		};
		textField.addKeyListener(presionarEnter1);
		
		KeyListener presionarEnter2 = new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {

			}

			@Override
			public void keyReleased(KeyEvent e) {

			}

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					if (!textField.getText().isBlank()) {
						Nombre nombre = new Nombre();
						nombre.setNombre(textField.getText());
						nombre.setApellidos(textField2.getText());
						modelo.getListaNombres().add(nombre);
						modelo.fireTableDataChanged();
					}
				}

			}
		};
		textField2.addKeyListener(presionarEnter2);
	}
}
