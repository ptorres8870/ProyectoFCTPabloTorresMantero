package ejerciciosRepaso;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;

public class ejercicio6 {

	private JFrame frame;
	private JTextField textField;
	private JLabel lblNewLabel_1;
	private JButton botonLimpieza;
	private JButton botonSeleccion;
	private JLabel jLabelSeleccion;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ejercicio6 window = new ejercicio6();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ejercicio6() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 240, 240));
		frame.getContentPane().setForeground(new Color(255, 0, 128));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().setBackground(Color.PINK);
		
		textField = new JTextField();
		textField.setBounds(48, 70, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel = new JLabel("Nueva ciudad:");
		lblNewLabel.setBounds(48, 45, 86, 14);
		frame.getContentPane().add(lblNewLabel);

		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.setToolTipText("Destinos disponibles:");
		comboBox.setBounds(203, 69, 105, 22);
		frame.getContentPane().add(comboBox);

		lblNewLabel_1 = new JLabel("Destinos disponibles:");
		lblNewLabel_1.setBounds(203, 45, 190, 14);
		frame.getContentPane().add(lblNewLabel_1);

		botonLimpieza = new JButton("Limpiar");
		botonLimpieza.setBounds(203, 102, 89, 23);
		frame.getContentPane().add(botonLimpieza);

		botonSeleccion = new JButton("Seleccionar");
		botonSeleccion.setBounds(203, 136, 89, 23);
		frame.getContentPane().add(botonSeleccion);
		botonSeleccion.setEnabled(false);

		jLabelSeleccion = new JLabel("");
		jLabelSeleccion.setBounds(203, 170, 190, 14);
		frame.getContentPane().add(jLabelSeleccion);

		KeyListener actionEnter = new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					comboBox.addItem(textField.getText());
					textField.setText(null);
					if (comboBox.getSelectedItem() != null) {
						comboBox.setSelectedItem(null);
					}
				}

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

		};
		textField.addKeyListener(actionEnter);

		ActionListener botonLimpiar = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				comboBox.removeAllItems();
				botonSeleccion.setEnabled(false);
				jLabelSeleccion.setText("");
			}
		};

		botonLimpieza.addActionListener(botonLimpiar);

		ActionListener botonSeleccionar = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				jLabelSeleccion.setText("Ciudad seleccionada: " + comboBox.getSelectedItem());
				jLabelSeleccion.setVisible(true);

			}
		};

		botonSeleccion.addActionListener(botonSeleccionar);

		ActionListener actionCombo = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (comboBox.getSelectedIndex() != -1) {
					botonSeleccion.setEnabled(true);
					
					
				}else {
					botonSeleccion.setEnabled(false);
				}

			}
		};
		comboBox.addActionListener(actionCombo);
	}
}
