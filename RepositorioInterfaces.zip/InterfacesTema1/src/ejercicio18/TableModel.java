package ejercicio18;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import ejercicio01.modelo.Pelicula;

public class TableModel extends AbstractTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<Pelicula> listaPelis;
	private List<String> listaColumnas;

	public TableModel() {
		listaPelis = new ArrayList<Pelicula>();
		listaColumnas = new ArrayList<String>();
		listaColumnas.add("Id");
		listaColumnas.add("Titulo");
		listaColumnas.add("Longitud");
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return listaPelis.size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return listaColumnas.size();
	}

	@Override
	public String getColumnName(int column) {
		// TODO Auto-generated method stub
		return listaColumnas.get(column);

	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		Pelicula peli = listaPelis.get(rowIndex);
		String nombreColumna = listaColumnas.get(columnIndex);
		if (nombreColumna.equals("id")) {
			return peli.getId();
		} else if (nombreColumna.equals("titulo")) {
			return peli.getNombre();
		} else {
			return peli.getLongitud();
		}
	}

	public List<Pelicula> getListaPelis() {
		return listaPelis;
	}

	public void setListaPelis(List<Pelicula> listaPelis) {
		this.listaPelis = listaPelis;
	}

	public List<String> getListaColumnas() {
		return listaColumnas;
	}

	public void setListaColumnas(List<String> listaColumnas) {
		this.listaColumnas = listaColumnas;
	}

}
