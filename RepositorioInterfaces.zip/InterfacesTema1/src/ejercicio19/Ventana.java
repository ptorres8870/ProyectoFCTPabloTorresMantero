package ejercicio19;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import ejercicio01.modelo.Pelicula;
import ejercicio01.services.PeliculasException;
import ejercicio01.services.PeliculasService;
import javax.swing.JCheckBox;

public class Ventana {

	private JFrame frame;
	private JTable table;
	private List<Pelicula> peli;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana window = new Ventana();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Ventana() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * @param <T>
	 */
	private <T> void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JButton botonConsultar = new JButton("Consultar");
		botonConsultar.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(botonConsultar);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 414, 160);
		frame.getContentPane().add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);
		TableModel modelo = new TableModel();
		table.setModel(modelo);

		JCheckBox checkBoxId = new JCheckBox("");
		checkBoxId.setBounds(10, 178, 97, 23);
		checkBoxId.setSelected(true);
		frame.getContentPane().add(checkBoxId);

		JCheckBox checkboxTitulo = new JCheckBox("");
		checkboxTitulo.setBounds(146, 178, 97, 23);
		checkboxTitulo.setSelected(true);
		frame.getContentPane().add(checkboxTitulo);

		JCheckBox checkBoxLongitud = new JCheckBox("");
		checkBoxLongitud.setBounds(287, 178, 97, 23);
		checkBoxLongitud.setSelected(true);
		frame.getContentPane().add(checkBoxLongitud);

		ActionListener pulsarBoton = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					PeliculasService peliService = new PeliculasService();
					peli = peliService.consultarPeliculas();
					List<String> listaColumnas = new ArrayList<String>();
					modelo.setListaPelis(peli);

					if (checkBoxId.isSelected()) {
						listaColumnas.add("id");
					}
					if (checkboxTitulo.isSelected()) {
						listaColumnas.add("titulo");
					}
					if (checkBoxLongitud.isSelected()) {
						listaColumnas.add("longitud");
					}
					modelo.setListaColumnas(listaColumnas);
					modelo.fireTableStructureChanged();
				} catch (PeliculasException e2) {
					JOptionPane.showMessageDialog(frame, e2.getMessage(), "ERROR BBDD", JOptionPane.ERROR_MESSAGE);
					e2.printStackTrace();
				}
			}
		};

		Comparator<Pelicula> comparadorId = new Comparator<>() {

			@Override
			public int compare(Pelicula o1, Pelicula o2) {
				return o1.getId().compareTo(o2.getId());
			}

		};
		Comparator<Pelicula> comparadorNombre = new Comparator<>() {

			@Override
			public int compare(Pelicula o1, Pelicula o2) {
				return o1.getNombre().compareTo(o2.getNombre());
			}

		};

		Comparator<Pelicula> comparadorLongitud = new Comparator<>() {

			@Override
			public int compare(Pelicula o1, Pelicula o2) {
				return o1.getLongitud().compareTo(o2.getLongitud());
			}

		};

		MouseListener clickHeader = new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				Integer column = table.columnAtPoint(e.getPoint());
				if (column == 0) {
					peli.sort(comparadorId);
				}
				if (column == 1) {
					peli.sort(comparadorNombre);
				} else {
					peli.sort(comparadorLongitud);
				}
			}
		};

		botonConsultar.addActionListener(pulsarBoton);
		table.getTableHeader().addMouseListener(clickHeader);
	}
}
