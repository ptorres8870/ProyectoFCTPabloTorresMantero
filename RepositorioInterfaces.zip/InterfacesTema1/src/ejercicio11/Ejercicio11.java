package ejercicio11;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.ItemSelectable;

import javax.swing.JFrame;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;

public class Ejercicio11 {

	private JFrame frame;
	private JTextField textTab1;
	private JTextField textTab2;
	private JTextField textTab3;
	private JTextField textTab4;
	private Color color;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ejercicio11 window = new Ejercicio11();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Ejercicio11() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 560, 470);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		textTab1 = new JTextField();
		textTab1.setBounds(66, 85, 125, 20);
		frame.getContentPane().add(textTab1);
		textTab1.setColumns(10);

		textTab2 = new JTextField();
		textTab2.setBounds(66, 135, 125, 20);
		frame.getContentPane().add(textTab2);
		textTab2.setColumns(10);

		textTab3 = new JTextField();
		textTab3.setBounds(66, 189, 125, 20);
		frame.getContentPane().add(textTab3);
		textTab3.setColumns(10);

		textTab4 = new JTextField();
		textTab4.setBounds(66, 234, 125, 20);
		frame.getContentPane().add(textTab4);
		textTab4.setColumns(10);

		JComboBox<String> combo = new JComboBox<String>();

		combo.setBounds(266, 84, 205, 22);
		frame.getContentPane().add(combo);
		combo.addItem("ROJO");
		combo.addItem("VERDE");
		combo.addItem("AZUL");
		combo.setFocusable(false);

		JRadioButton botonRojo = new JRadioButton("ROJO");
		botonRojo.setBounds(266, 134, 109, 23);
		frame.getContentPane().add(botonRojo);

		JRadioButton botonVerde = new JRadioButton("VERDE");
		botonVerde.setBounds(266, 175, 109, 23);
		frame.getContentPane().add(botonVerde);

		JRadioButton botonAzul = new JRadioButton("AZUL");
		botonAzul.setBounds(266, 217, 109, 23);
		frame.getContentPane().add(botonAzul);

		ButtonGroup group = new ButtonGroup();
		group.add(botonRojo);
		group.add(botonVerde);
		group.add(botonAzul);

		ActionListener radio = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				if (e.getSource() == botonRojo) {
					combo.setSelectedItem("ROJO");
				} else if (e.getSource() == botonVerde) {
					combo.setSelectedItem("VERDE");
				} else if (e.getSource() == botonAzul) {
					combo.setSelectedItem("AZUL");
				}
			}
		};

		botonRojo.addActionListener(radio);
		botonVerde.addActionListener(radio);
		botonAzul.addActionListener(radio);

		ItemListener item = new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				if (combo.getSelectedItem().equals("ROJO")) {
					color = Color.RED;
					botonRojo.setSelected(true);
				} else if (combo.getSelectedItem().equals("VERDE")) {
					color = Color.GREEN;
					botonVerde.setSelected(true);
				} else if (combo.getSelectedItem().equals("AZUL")) {
					color = Color.BLUE;
					botonAzul.setSelected(true);
				}
			}
		};

		combo.addItemListener(item);
		FocusListener focus = new FocusListener() {

			@Override
			public void focusLost(FocusEvent e) {
				JTextField colorChange = new JTextField();
				colorChange = (JTextField) e.getSource();
				colorChange.setBackground(Color.WHITE);

			}

			@Override
			public void focusGained(FocusEvent e) {
				JTextField colorChange = new JTextField();
				colorChange = (JTextField) e.getSource();
				colorChange.setBackground(color);
			}
		};

		textTab1.addFocusListener(focus);
		textTab2.addFocusListener(focus);
		textTab3.addFocusListener(focus);
		textTab4.addFocusListener(focus);

		KeyListener keyListen = new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {

			}

			@Override
			public void keyReleased(KeyEvent e) {

			}

			@Override
			public void keyPressed(KeyEvent e) {

				if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_ENTER) {
					JTextField transferT = new JTextField();
					transferT = (JTextField) e.getSource();
					transferT.transferFocus();
				}

				if (e.getKeyCode() == KeyEvent.VK_UP) {
					JTextField transferT = new JTextField();
					transferT = (JTextField) e.getSource();
					transferT.transferFocusBackward();
				}

			}

		};

		textTab1.addKeyListener(keyListen);
		textTab2.addKeyListener(keyListen);
		textTab3.addKeyListener(keyListen);
		textTab4.addKeyListener(keyListen);
	}
}
