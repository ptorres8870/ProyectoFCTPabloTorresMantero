package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class BienvenidaController extends AppController {
	@FXML
	private Label bienvenidaLabel;

	public void setNombreBienvenida(String nombre) {
		bienvenidaLabel.setText(nombre);
	}

	public void entrar(ActionEvent event) {
		cambiarVista(FXML_PRINCIPAL);
	}

}
