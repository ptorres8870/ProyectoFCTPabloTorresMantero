package controllers;

import java.util.Optional;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class LoginController extends AppController {

	@FXML
	private TextField user;

	public void entrar() {
		BienvenidaController bienvenidaController = (BienvenidaController) cambiarVista(FXML_BIENVENIDA);
		bienvenidaController.setNombreBienvenida("Bienvenid@ " + user.getText());
	}

	public void registrarse(ActionEvent event) {
		cambiarVista(FXML_REGISTRO);
	}

	public void salir(ActionEvent event) {
		Alert a = new Alert(AlertType.CONFIRMATION);
		a.setHeaderText(null);
		a.setContentText("¿Cerrar la aplicación?");
		Optional<ButtonType> result = a.showAndWait();
		if (result.get() == ButtonType.OK) {
			System.exit(0);
		} else {
			cambiarVista(FXML_LOGIN);
		}
	}
}
