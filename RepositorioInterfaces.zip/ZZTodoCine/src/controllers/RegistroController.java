package controllers;

import javafx.event.ActionEvent;

public class RegistroController extends AppController {
	public void registrarse(ActionEvent event) {
		cambiarVista(FXML_LOGIN);
	}

	public void volver(ActionEvent event) {
		cambiarVista(FXML_LOGIN);
	}
}
