package controllers;

import java.util.Optional;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import modelo.Pelicula;

public class PrincipalController extends AppController {

	@FXML
	private BorderPane pane;
	@FXML
	private TableView<Pelicula> tabla;
	@FXML
	private TableColumn<Pelicula, String> columnaNombre;
	@FXML
	private TableColumn<Pelicula, Integer> columnaDuracion;
	@FXML
	private TableColumn<Pelicula, String> columnaTipo;

	private ObservableList<Pelicula> datos;

	@FXML
	public void initialize() {
		columnaNombre.setCellValueFactory(new PropertyValueFactory<Pelicula, String>("nombre"));
		columnaDuracion.setCellValueFactory(new PropertyValueFactory<Pelicula, Integer>("duracion"));
		columnaTipo.setCellValueFactory(new PropertyValueFactory<Pelicula, String>("tipo"));

		datos = FXCollections.observableArrayList();
		tabla.setItems(datos);
	}

	public void volverPrincipal(ActionEvent event) {
		cambiarVista(FXML_PRINCIPAL);
	}

	public void irPantallaCrear(ActionEvent event) {
		pane.setCenter(cargarVista(FXML_CREAR));
	}

	public void irPantallaActualizar(ActionEvent event) {
		pane.setCenter(cargarVista(FXML_ACTUALIZAR));
	}

	public void irPantallaLeer(ActionEvent event) {
		pane.setCenter(cargarVista(FXML_LEER));
	}

	public void irPantallaBorrar(ActionEvent event) {
		pane.setCenter(cargarVista(FXML_BORRAR));
	}

	public void salir(ActionEvent event) {
		Alert a = new Alert(AlertType.CONFIRMATION);
		a.setHeaderText(null);
		a.setContentText("¿Cerrar la aplicación?");
		Optional<ButtonType> result = a.showAndWait();
		if (result.get() == ButtonType.OK) {
			System.exit(0);
		} else {
			cambiarVista(FXML_PRINCIPAL);
		}
	}
}
