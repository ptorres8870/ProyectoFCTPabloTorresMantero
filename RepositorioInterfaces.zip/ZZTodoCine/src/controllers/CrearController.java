package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;

public class CrearController {
	@FXML
	private Slider slider;
	@FXML
	private TextField duracion;

	public void leer(ActionEvent event) {
		slider.setValue(Integer.parseInt(duracion.getText()));

	}
}
