package modelo;

public class Pelicula {

	private String nombre;
	private Integer duracion;
	private String tipo;

	public Pelicula() {
	}

	public Pelicula(String nombre, Integer duracion, String tipo) {
		this.nombre = nombre;
		this.duracion = duracion;
		this.tipo = tipo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getDuracion() {
		return duracion;
	}

	public void setDuracion(Integer duracion) {
		this.duracion = duracion;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return "Pelicula [nombre=" + nombre + ", duracion=" + duracion + ", tipo=" + tipo + "]";
	}

}
