package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;

public class ColorController {

	@FXML
	private ColorPicker colorPicker;

	@FXML
	private Label label;

	public ColorController() {
	}

	public void aplicar(ActionEvent event) {
		label.setTextFill(colorPicker.getValue());
	}

}
