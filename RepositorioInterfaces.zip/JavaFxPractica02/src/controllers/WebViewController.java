package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.web.WebView;

public class WebViewController {

	@FXML
	public TextField textField;

	@FXML
	public WebView webView;

	public WebViewController() {
	}

	public void cargar(ActionEvent event) {
		webView.getEngine().load(textField.getText());
	}

}
