package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

public class ComboController {

	@FXML
	private ComboBox<String> comboBox;

	@FXML
	private Label label;

	public ComboController() {

	}

	public void limpiar() {
		label.setText("");
		comboBox.setValue("");
	}

	public void imprimir() {
		label.setText(comboBox.getValue());
	}

	public void initialize() {
		comboBox.getItems().addAll("Blau", "Blas", "Laura");
	}
}
