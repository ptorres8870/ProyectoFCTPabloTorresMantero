package controllers;

import java.util.Optional;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.BorderPane;

public class BienvenidaController extends AppController {

	@FXML
	private BorderPane pane;

	public BienvenidaController() {
	}

	public void cargarPantallaComboBox(ActionEvent event) {
		pane.setCenter(cargarVista(FXML_COMBO));
	}

	public void cargarPantallaDatePicker(ActionEvent event) {
		pane.setCenter(cargarVista(FXML_DATE));
	}

	public void cargarPantallaColorPicker(ActionEvent event) {
		pane.setCenter(cargarVista(FXML_COLOR));
	}

	public void cargararPantallaSlider(ActionEvent event) {
		pane.setCenter(cargarVista(FXML_SLIDER));
	}

	public void cargararPantallaWebView(ActionEvent event) {
		pane.setCenter(cargarVista(FXML_WEB));
	}
	public void cargararPantallaHTMLEditor(ActionEvent event) {
		pane.setCenter(cargarVista(FXML_HTML));
	}

	public void salir() {
		Alert a = new Alert(AlertType.CONFIRMATION);
		a.setHeaderText(null);
		a.setContentText("¿Cerrar la aplicación?");
		Optional<ButtonType> result = a.showAndWait();
		if (result.get() == ButtonType.OK) {
			System.exit(0);
		}else {
			cambiarVista(FXML_BIENVENIDA);
		}
	}

	public void cerrarSesion() {
		cambiarVista(FXML_LOGIN);
	}
}
