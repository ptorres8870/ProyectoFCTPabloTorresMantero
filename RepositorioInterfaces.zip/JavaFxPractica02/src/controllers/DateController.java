package controllers;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.util.converter.LocalDateStringConverter;

public class DateController {

	@FXML
	private DatePicker datePicker;

	@FXML
	private Label label;

	public DateController() {
	}

	public void leer() {
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		label.setText(datePicker.getValue().format(formato));

	}

	public void initialize() {
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		datePicker.setConverter(new LocalDateStringConverter(formato, formato));
		datePicker.setValue(LocalDate.now());
		label.setText(LocalDate.now().toString());
	}
}
