package controllers;

import java.util.Optional;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import services.LoginService;

public class LoginController extends AppController {

	@FXML
	private Label labelCorrecto;
	@FXML
	private Label labelNombre;
	@FXML
	private TextField tfUsuario;
	@FXML
	private PasswordField tfPassword;
	@FXML
	private Pane pane;

	private LoginService service;

	public void verificarEntrada() {
			labelCorrecto.setDisable(false);
			labelNombre.setDisable(false);
			labelCorrecto.setText("Acceso Correcto");
			BienvenidaController controller = (BienvenidaController) cambiarVista(FXML_BIENVENIDA);

	}

	public void salir() {
		Alert a = new Alert(AlertType.CONFIRMATION);
		a.setHeaderText(null);
		a.setContentText("¿Cerrar la aplicación?");
		Optional<ButtonType> result = a.showAndWait();
		if (result.get() == ButtonType.OK) {
			System.exit(0);
		}else {
			cambiarVista(FXML_LOGIN);
		}
	}

	public void initialize() {
		service = new LoginService();
		Platform.runLater(new Runnable() {

			@Override
			public void run() {
				tfUsuario.requestFocus();
			}
		});
	}
}
