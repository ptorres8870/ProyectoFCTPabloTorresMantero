package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;

public class SliderController {

	@FXML
	private Slider slider;

	@FXML
	private Label label;

	public SliderController() {
	}

	public void leer() {
		label.setText(String.format("%.2f", slider.getValue()) + "");

	}
}
