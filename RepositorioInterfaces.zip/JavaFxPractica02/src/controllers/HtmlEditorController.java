package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.web.HTMLEditor;

public class HtmlEditorController {

	@FXML
	public HTMLEditor htmlEditor;

	public HtmlEditorController() {
	}

	public void cargar(ActionEvent event) {
		System.out.println(htmlEditor.getHtmlText());
		
	}
}
