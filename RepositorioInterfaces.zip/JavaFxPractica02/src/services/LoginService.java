package services;

import java.util.Date;

import modelos.Usuario;


public class LoginService {

	public Usuario login(String username, String password) throws LoginDenegadoException {
		Usuario usuario = new Usuario("Doramion", "Sevilla", new Date());
		if ("test".equals(username) && "pass".equals(password)) {
			return usuario;
		}
		throw new LoginDenegadoException("Usuario/Password incorrectos");
	}

}
