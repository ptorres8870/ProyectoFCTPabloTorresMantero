package app.gui.login;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class LoginController {

	@FXML
	public TextField tfNombre;

	public void escribirTexto() {
		System.out.println(tfNombre.getText());
		tfNombre.setText("");
	}

}
