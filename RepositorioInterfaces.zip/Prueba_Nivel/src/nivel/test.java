package nivel;

import java.util.ArrayList;
import java.util.Scanner;

public class test {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		ArrayList<Persona> listaPersonas = new ArrayList<>();

		for (int contador = 1; contador <= 3; contador++) {

			Persona p1 = new Persona();

			System.out.println("Dime el dni del alumno:");
			String dni = scanner.nextLine();
			p1.setDni(dni);
			System.out.println("Dime el nombre del alumno:");
			String nombre = scanner.nextLine();
			p1.setNombre(nombre);

			listaPersonas.add(p1);
		}

		for (int contador = 0; contador < listaPersonas.size(); contador++) {
			
			System.out.println(listaPersonas.get(contador).getDni());
			System.out.println(listaPersonas.get(contador).getNombre());

		}

		scanner.close();
	}
}
