package interfaz;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;

public class BienvenidaView extends View {
	private JLabel labelNombre;

	public BienvenidaView(AppController appController) {
		super(appController);
		setLayout(null);

		labelNombre = new JLabel();
		labelNombre.setFont(new Font("Tahoma", Font.PLAIN, 35));
		labelNombre.setHorizontalAlignment(SwingConstants.CENTER);
		labelNombre.setBounds(124, 57, 211, 187);
		add(labelNombre);
	}

	public void mensajeBienvenida() {
		labelNombre.setText("Hola, " + appController.getUsuario().getNombre());
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@Override
	public void limpiarFormularios() {
	}
}
