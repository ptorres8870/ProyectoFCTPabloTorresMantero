package interfaz;

import javax.swing.JPanel;

public abstract class View extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected AppController appController;

	public View(AppController appController) {
		this.appController = appController;
	}

	public abstract void limpiarFormularios();
}
