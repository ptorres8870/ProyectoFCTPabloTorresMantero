package interfaz;

import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JSlider;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.mariadb.jdbc.plugin.codec.LocalDateCodec;

import model.Registro;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class NuevoRegistroView extends View {
	public NuevoRegistroView(AppController appController) {
		super(appController);
		setLayout(null);

		JLabel labelFecha = new JLabel("Fecha:");
		labelFecha.setBounds(60, 38, 159, 14);
		add(labelFecha);

		JComboBox<String> comboBoxFecha = new JComboBox<String>();
		comboBoxFecha.setBounds(60, 63, 159, 22);
		add(comboBoxFecha);

		JLabel labelHoras = new JLabel("Hora:");
		labelHoras.setBounds(60, 96, 159, 14);
		add(labelHoras);

		JSlider slider = new JSlider();
		slider.setMaximum(16);
		slider.setMajorTickSpacing(5);
		slider.setValue(0);
		slider.setMinorTickSpacing(1);
		slider.setPaintTicks(true);
		slider.setBounds(60, 121, 237, 31);
		add(slider);

		JLabel labelTareas = new JLabel("Tareas realizadas:");
		labelTareas.setBounds(60, 158, 159, 14);
		add(labelTareas);

		JButton botonCancelar = new JButton("Cancelar");
		botonCancelar.setBounds(351, 266, 89, 23);
		add(botonCancelar);

		JButton botonAceptar = new JButton("Aceptar");
		botonAceptar.setBounds(252, 266, 89, 23);
		add(botonAceptar);

		JLabel labelValores = new JLabel("0");
		labelValores.setHorizontalAlignment(SwingConstants.CENTER);
		labelValores.setBounds(307, 121, 46, 26);
		add(labelValores);

		ChangeListener changeSlider = new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				BigDecimal valor = new BigDecimal(slider.getValue()).divide(new BigDecimal(2), 1,
						RoundingMode.HALF_DOWN);
				labelValores.setText(valor.toString());
			}
		};
		slider.addChangeListener(changeSlider);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(60, 182, 339, 73);
		add(scrollPane);

		JTextArea textArea = new JTextArea();
		textArea.setLineWrap(true);
		scrollPane.setViewportView(textArea);

		ActionListener actionBotones = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == botonAceptar) {
					Registro registro = new Registro();
					DateTimeFormatter formatoFechas = DateTimeFormatter.ofPattern("dd/MM/yyyy");
					
					registro.setFecha(comboBoxFecha.getSelectedItem());
					registro.setNum_horas(new BigDecimal(slider.getValue()));
					registro.setDescripcion(textArea.getText());
					registro.setId_usuario(appController.getUsuario().getId_usuario());
				}
				if (e.getSource() == botonCancelar) {
					appController.irPantallaBienvenida();
				}

			}
		};

		botonAceptar.addActionListener(actionBotones);
		botonCancelar.addActionListener(actionBotones);

		appController.insertarFechasComboBox(comboBoxFecha);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void limpiarFormularios() {
		// TODO Auto-generated method stub

	}
}
