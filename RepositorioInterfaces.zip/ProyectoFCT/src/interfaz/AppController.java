package interfaz;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import exception.AutenticarException;
import exception.EvalucianException;
import exception.FechaServiceException;
import exception.RegistroServiceException;
import exception.UsuarioServiceException;
import model.Fecha;
import model.Registro;
import model.Usuario;
import services.FechaService;
import services.RegistroService;
import services.UsuarioService;

import javax.swing.JMenuBar;

public class AppController {

	private JFrame frame;
	private BienvenidaView pantallaBienvenida;
	private ConsultarRegistroView pantallaConsultarRegistros;
	private LoginView pantallaLogin;
	private NuevoRegistroView pantallaNuevoRegistro;
	private SolicitarAccesoView pantallaSolicitarAcceso;
	private JMenu menuApp;
	private JMenu menuRegistro;
	private JMenuItem itemCerrarSesion;
	private JMenuItem itemSalir;
	private JMenuItem itemNuevoRegistro;
	private JMenuItem itemConsultarRegistro;
	private Usuario usuario;

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AppController window = new AppController();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AppController() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(650, 250, 700, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		pantallaBienvenida = new BienvenidaView(this);
		pantallaConsultarRegistros = new ConsultarRegistroView(this);
		pantallaLogin = new LoginView(this);
		pantallaSolicitarAcceso = new SolicitarAccesoView(this);
		pantallaNuevoRegistro = new NuevoRegistroView(this);

		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);

		menuApp = new JMenu("App");
		menuBar.add(menuApp);

		itemCerrarSesion = new JMenuItem("Cerrar sesión");
		menuApp.add(itemCerrarSesion);

		itemSalir = new JMenuItem("Salir");
		menuApp.add(itemSalir);

		menuRegistro = new JMenu("Registro");
		menuBar.add(menuRegistro);

		itemNuevoRegistro = new JMenuItem("Crear nuevo registro");
		menuRegistro.add(itemNuevoRegistro);

		itemConsultarRegistro = new JMenuItem("Consultar registros");
		menuRegistro.add(itemConsultarRegistro);
		frame.setContentPane(pantallaLogin);
		frame.revalidate();

		ActionListener actionMenu = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == itemCerrarSesion) {
					irPantallaLogin();
				}
				if (e.getSource() == itemSalir) {
					System.exit(0);
				}
				if (e.getSource() == itemNuevoRegistro) {
					irPantallaNuevoRegistro();
				}
				if (e.getSource() == itemConsultarRegistro) {
					irPantallaConsultarRegistros();
				}

			}
		};

		itemCerrarSesion.addActionListener(actionMenu);
		itemSalir.addActionListener(actionMenu);
		itemNuevoRegistro.addActionListener(actionMenu);
		itemConsultarRegistro.addActionListener(actionMenu);

		irPantallaLogin();
	}

	public void cambiarPantalla(View view) {
		frame.setContentPane(view);
		view.limpiarFormularios();
		frame.revalidate();
	}

	public void altaUsuario(Usuario u) {
		UsuarioService usuService = new UsuarioService();
		try {
			usuService.altaUsuario(u);
		} catch (UsuarioServiceException e) {
			JOptionPane.showMessageDialog(pantallaSolicitarAcceso, e.getMessage());
			e.printStackTrace();
		}
	}

	public void consultarUsuario(String email, String pass) {
		UsuarioService usuService = new UsuarioService();
		try {
			usuario = usuService.loginUsuario(email, pass);
			JOptionPane.showMessageDialog(pantallaLogin, "Entrando a su perfil...");
			irPantallaBienvenida();
		} catch (UsuarioServiceException | AutenticarException e) {
			JOptionPane.showMessageDialog(pantallaLogin, e.getMessage());
		}

	}

	public void insertarRegistros(Registro registro) {
		RegistroService registroService = new RegistroService();
		try {
			registroService.insertarRegistro(registro);
		} catch (RegistroServiceException e) {
			JOptionPane.showMessageDialog(pantallaNuevoRegistro, e.getMessage());
			e.printStackTrace();
		}
	}

	public void insertarFechasComboBox(JComboBox<String> combo) {
		FechaService fechaService = new FechaService();
		List<Fecha> listaFechas = new ArrayList<Fecha>();
		try {
			listaFechas = fechaService.consultarFechaActuales();
			for (Fecha fecha : listaFechas) {
				DateTimeFormatter formatoFechas = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				combo.addItem(fecha.getFecha().format(formatoFechas));

			}
		} catch (FechaServiceException | EvalucianException e) {
			JOptionPane.showMessageDialog(pantallaNuevoRegistro, e.getMessage());
			e.printStackTrace();
		}
	}

	public void refrescar() {
		RegistroService registroService = new RegistroService();
		List<Registro> listaRegistros = new ArrayList<>();
		try {
			listaRegistros = registroService.consultarTodosRegistrosUsuario(usuario.getId_usuario());
		} catch (RegistroServiceException e) {
			JOptionPane.showMessageDialog(pantallaNuevoRegistro, e.getMessage());
			e.printStackTrace();
		}
		pantallaConsultarRegistros.getModelo().setListaRegistro(listaRegistros);
		pantallaConsultarRegistros.getModelo().fireTableDataChanged();
	}

	public void salirPrograma() {
		String st = "Error al introducir los datos.";
		JOptionPane.showMessageDialog(null, st);
	}

	public void irPantallaBienvenida() {
		menuRegistro.setVisible(true);
		menuApp.setVisible(true);
		pantallaBienvenida.mensajeBienvenida();
		cambiarPantalla(pantallaBienvenida);
	}

	public void irPantallaConsultarRegistros() {
		menuRegistro.setVisible(true);
		menuApp.setVisible(true);
		cambiarPantalla(pantallaConsultarRegistros);

	}

	public void irPantallaLogin() {
		menuRegistro.setVisible(false);
		menuApp.setVisible(false);
		cambiarPantalla(pantallaLogin);
	}

	public void irPantallaSolicitarAcceso() {
		menuRegistro.setVisible(false);
		menuApp.setVisible(false);
		cambiarPantalla(pantallaSolicitarAcceso);
	}

	public void irPantallaNuevoRegistro() {
		menuRegistro.setVisible(true);
		menuApp.setVisible(true);
		cambiarPantalla(pantallaNuevoRegistro);
	}
}
