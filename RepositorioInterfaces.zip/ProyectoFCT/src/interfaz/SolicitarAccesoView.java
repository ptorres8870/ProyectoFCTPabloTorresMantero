package interfaz;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.Usuario;

import javax.swing.JComboBox;
import javax.swing.JPasswordField;

public class SolicitarAccesoView extends View {

	private JComboBox<String> comboBoxCiclo;

	public SolicitarAccesoView(AppController appController) {
		super(appController);
		setLayout(null);

		JButton botonCancelar = new JButton("Cancelar");
		botonCancelar.setBounds(351, 386, 89, 23);
		add(botonCancelar);

		JButton botonAceptar = new JButton("Aceptar");
		botonAceptar.setBounds(252, 386, 89, 23);
		add(botonAceptar);

		JLabel labelEmail = new JLabel("Email:");
		labelEmail.setBounds(159, 11, 132, 14);
		add(labelEmail);

		textFieldEmail = new JTextField();
		textFieldEmail.setBounds(159, 36, 132, 20);
		add(textFieldEmail);
		textFieldEmail.setColumns(10);

		JLabel labelContraseña = new JLabel("Contraseña:");
		labelContraseña.setBounds(159, 67, 132, 14);
		add(labelContraseña);

		JLabel labelRepetir = new JLabel("Repetir contraseña:");
		labelRepetir.setBounds(159, 123, 132, 14);
		add(labelRepetir);

		JLabel labelNombre = new JLabel("Nombre:");
		labelNombre.setBounds(159, 179, 132, 14);
		add(labelNombre);

		textFieldNombre = new JTextField();
		textFieldNombre.setBounds(159, 204, 132, 20);
		add(textFieldNombre);
		textFieldNombre.setColumns(10);

		JLabel labelApellido = new JLabel("Apellidos:");
		labelApellido.setBounds(159, 235, 132, 14);
		add(labelApellido);

		textFieldApellidos = new JTextField();
		textFieldApellidos.setBounds(159, 260, 132, 20);
		add(textFieldApellidos);
		textFieldApellidos.setColumns(10);

		JLabel labelCiclo = new JLabel("Ciclo formativo:");
		labelCiclo.setBounds(159, 291, 132, 14);
		add(labelCiclo);

		comboBoxCiclo = new JComboBox<>();
		comboBoxCiclo.setBounds(159, 320, 132, 22);
		comboBoxCiclo.addItem("DAM");
		comboBoxCiclo.addItem("DAW");
		comboBoxCiclo.addItem("ASIR");
		comboBoxCiclo.setSelectedIndex(-1);
		add(comboBoxCiclo);

		passwordField = new JPasswordField();
		passwordField.setBounds(159, 92, 132, 20);
		add(passwordField);

		passwordRepetirField = new JPasswordField();
		passwordRepetirField.setBounds(159, 148, 132, 20);
		add(passwordRepetirField);

		ActionListener actionBotones = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == botonAceptar) {
					if (validar() == true) {
						String pass = String.valueOf(passwordField.getPassword());
						Usuario usu = new Usuario();
						usu.setEmail(textFieldEmail.getText());
						usu.setCiclo(String.valueOf(comboBoxCiclo.getSelectedIndex()));
						usu.setNombre(textFieldNombre.getText());
						usu.setApellidos(textFieldApellidos.getText());
						usu.setPassword(pass);

						appController.altaUsuario(usu);
						appController.irPantallaLogin();
					} else {
						String st = "Error al introducir los datos.";
						JOptionPane.showMessageDialog(null, st);
					}
				}
				if (e.getSource() == botonCancelar) {
					appController.irPantallaLogin();
				}

			}

		};

		botonAceptar.addActionListener(actionBotones);
		botonCancelar.addActionListener(actionBotones);
	}

	public Boolean validar() {
		String pass = String.valueOf(passwordField.getPassword());
		String passRepe = new String(passwordRepetirField.getPassword());
		if (pass.equals(passRepe) && !pass.isEmpty() && !passRepe.isEmpty() && !textFieldEmail.getText().isEmpty()
				&& !textFieldNombre.getText().isEmpty() && !textFieldApellidos.getText().isEmpty()
				&& comboBoxCiclo.getSelectedItem() != null) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textFieldEmail;
	private JTextField textFieldNombre;
	private JTextField textFieldApellidos;
	private JPasswordField passwordField;
	private JPasswordField passwordRepetirField;

	@Override
	public void limpiarFormularios() {
		textFieldEmail.setText("");
		textFieldNombre.setText("");
		textFieldApellidos.setText("");
		passwordField.setText("");
		passwordRepetirField.setText("");
		comboBoxCiclo.setSelectedIndex(-1);

	}
}
