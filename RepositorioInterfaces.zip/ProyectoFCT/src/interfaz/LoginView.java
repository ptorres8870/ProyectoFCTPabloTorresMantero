package interfaz;

import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPasswordField;

public class LoginView extends View {
	public LoginView(AppController appController) {
		super(appController);
		setLayout(null);

		JLabel labelEmail = new JLabel("E-mail:");
		labelEmail.setBounds(133, 77, 152, 14);
		add(labelEmail);

		textFieldEmail = new JTextField();
		textFieldEmail.setBounds(133, 102, 152, 20);
		add(textFieldEmail);
		textFieldEmail.setColumns(10);

		JLabel labelContraseña = new JLabel("Contraseña:");
		labelContraseña.setBounds(133, 133, 152, 14);
		add(labelContraseña);

		JButton botonEntrar = new JButton("Entrar");
		botonEntrar.setBounds(194, 189, 89, 23);
		add(botonEntrar);

		JButton botonSolicitar = new JButton("Solicitar acceso...");
		botonSolicitar.setBounds(175, 266, 152, 23);
		add(botonSolicitar);

		JButton botonSalir = new JButton("Salir");
		botonSalir.setBounds(351, 266, 89, 23);
		add(botonSalir);

		passwordField = new JPasswordField();
		passwordField.setBounds(133, 158, 152, 14);
		add(passwordField);

		ActionListener pulsarBoton = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == botonEntrar) {
					if (validar()) {
						appController.consultarUsuario(textFieldEmail.getText(),
								String.valueOf(passwordField.getPassword()));
					}
				}
				if (e.getSource() == botonSolicitar) {
					appController.irPantallaSolicitarAcceso();
				}
				if (e.getSource() == botonSalir) {
					appController.salirPrograma();
				}

			}
		};
		botonEntrar.addActionListener(pulsarBoton);
		botonSolicitar.addActionListener(pulsarBoton);
		botonSalir.addActionListener(pulsarBoton);
	}

	public Boolean validar() {
		String pass = String.valueOf(passwordField.getPassword());
		if (!pass.isEmpty() && !textFieldEmail.getText().isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textFieldEmail;
	private JPasswordField passwordField;

	@Override
	public void limpiarFormularios() {
		textFieldEmail.setText("");
		passwordField.setText("");
	}
}
