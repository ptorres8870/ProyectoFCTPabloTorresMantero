package interfaz;

import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;

public class ConsultarRegistroView extends View {

	private TableModel modelo;

	public TableModel getModelo() {
		return modelo;
	}

	public void setModelo(TableModel modelo) {
		this.modelo = modelo;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTable tablaRegistros;

	public ConsultarRegistroView(AppController appController) {
		super(appController);
		setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(42, 46, 369, 209);
		add(scrollPane);

		tablaRegistros = new JTable();
		tablaRegistros.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Fecha", "Horas", "Tareas" }));
		tablaRegistros.getColumnModel().getColumn(0).setPreferredWidth(128);
		tablaRegistros.getColumnModel().getColumn(1).setPreferredWidth(142);
		tablaRegistros.getColumnModel().getColumn(2).setPreferredWidth(478);
		scrollPane.setViewportView(tablaRegistros);

		JButton botonRefrescar = new JButton("Refrescar");
		botonRefrescar.setBounds(272, 266, 139, 23);
		add(botonRefrescar);

		modelo = new TableModel();
		tablaRegistros.setModel(modelo);
		ActionListener actionRefrescar = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				appController.refrescar();
			}
		};
		botonRefrescar.addActionListener(actionRefrescar);
	}

	@Override
	public void limpiarFormularios() {
		// TODO Auto-generated method stub

	}

}
